from django.apps import AppConfig


class DemoDjango001Config(AppConfig):
    name = 'demo_django_001'
